import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import api from "../../services/api";
import estilo from "./Cadastro.module.css";

export default function Cadastro() {

  const navigate = useNavigate();

  const [estados, setEstados] = useState([]);
  const [cidades, setCidades] = useState([]);

  const [form, setForm] = useState({
    nome: "",
    email: "",
    senha: "",
    cpf_cnpj: "",
    logradouro: "",
    bairro: "",
    numero: "",
    complemento: "",
    cidadeId: ""
  });

  // Buscar estados ao abrir a página
  useEffect(() => {
    const fetchEstados = async () => {
      try {
        const response = await api.get("/ibge/estados");

        const estadosFormatados = response.data.map((estado) => ({
          value: estado.id,
          label: `${estado.nome} (${estado.sigla})`,
        }));

        setEstados(estadosFormatados);
      } catch (error) {
        console.error("Erro ao buscar estados", error);
      }
    };
    fetchEstados();
  }, []);

  // Quando o estado muda → buscar cidades
  const handleEstadoChange = async (selected) => {
    try {
      const response = await api.get(`/ibge/cidades/${selected.value}`);

      const cidadesFormatadas = response.data.map((cidade) => ({
        value: cidade.id,
        label: cidade.nome,
      }));

      setCidades(cidadesFormatadas);
    } catch (error) {
      console.error("Erro ao buscar cidades", error);
    }
  };

  const handleCidadeChange = (selected) => {
    setForm({ ...form, cidadeId: selected.value });
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await api.post("/auth/register", {
        nome: form.nome,
        email: form.email,
        senha: form.senha,
        cpf_cnpj: form.cpf_cnpj,
        logradouro: form.logradouro,
        numero: form.numero,
        bairro: form.bairro,
        complemento: form.complemento,
        cidadeId: Number(form.cidadeId)
      });

      alert("Cadastro realizado com sucesso!");
      navigate("/login");
    } catch (error) {
      console.error("Erro no cadastro:", error);
      alert(error.response?.data || "Falha no cadastro.");
    }
  };

  // ESTILO DARK DO react-select
  const selectStyles = {
    control: (base) => ({
      ...base,
      backgroundColor: "#1a1a1a",
      borderColor: "#555",
      padding: "4px 5px",
      borderRadius: "15px",
      color: "#fff",
      boxShadow: "none",
    }),
    singleValue: (base) => ({
      ...base,
      color: "#fff",
    }),
    menu: (base) => ({
      ...base,
      backgroundColor: "#111",
      color: "#fff",
    }),
    option: (base, state) => ({
      ...base,
      backgroundColor: state.isFocused ? "#333" : "#111",
      color: "#fff",
      cursor: "pointer",
    }),
    placeholder: (base) => ({
      ...base,
      color: "#ccc",
    }),
  };

  return (
    <div className={estilo.cont}>
      <div className={estilo.container}>
        <form onSubmit={handleSubmit}>
          <h1>Crie sua Conta</h1>

          <div className={estilo.inputfield}>
            <input type="email" name="email" placeholder="E-mail" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="password" name="senha" placeholder="Senha" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="cpf_cnpj" placeholder="CPF/CNPJ" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="nome" placeholder="Nome" required onChange={handleChange} />
          </div>

          {/* ESTADO + CIDADE COM REACT-SELECT */}
          <div className={estilo.flexLine}>
            <div className={estilo.inputfield}>
              <Select
                options={estados}
                styles={selectStyles}
                placeholder="Selecione o Estado"
                onChange={handleEstadoChange}
              />
            </div>

            <div className={estilo.inputfield}>
              <Select
                options={cidades}
                styles={selectStyles}
                placeholder="Selecione a Cidade"
                onChange={handleCidadeChange}
                isDisabled={cidades.length === 0}
              />
            </div>
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="logradouro" placeholder="Logradouro" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="bairro" placeholder="Bairro" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="numero" placeholder="Número" required onChange={handleChange} />
          </div>

          <div className={estilo.inputfield}>
            <input type="text" name="complemento" placeholder="Complemento" onChange={handleChange} />
          </div>

          <button type="submit">Cadastrar</button>
        </form>
      </div>
    </div>
  );
}
