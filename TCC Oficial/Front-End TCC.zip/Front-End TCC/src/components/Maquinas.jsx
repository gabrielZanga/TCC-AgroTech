import styles from "./produto.module.css";
import trator1 from "../assets/trator1.png";
import trator2 from "../assets/trator2.png";
import trator3 from "../assets/trator3.png";
import trator4 from "../assets/trator4.png";
import trator5 from "../assets/trator5.png";
import { Link } from "react-router-dom";

export default function Produto(){
    return(
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.filtro}>
                    <div className={styles.fpreco}>
                        <h1>Preço</h1>

                        <div className={styles.marcar}>
                            <div className={styles.primeiro}>
                                <h2>R$100,00 até R$500,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.segundo}>
                                <h2>R$500,00 até R$1000,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.terceiro}>
                                <h2>R$1000,00 até R$5000,00</h2>
                                <input type="checkbox"/>
                            </div>

                            <div className={styles.menor}>
                                <h1>Menor Preço</h1>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.maior}>
                                <h1>Maior Preço</h1>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>

                    <div className={styles.fcategoria}>
                        <h1>Categorias</h1>

                        <div className={styles.marcar}>
                            <div className={styles.cprimeiro}>
                                <h2>Todos os Produtos</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.csegundo}>
                                <h2>Maquinários</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cterceiro}>
                                <h2>Peças</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cquarto}>
                                <h2>Serviços</h2>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={styles.gprod}>
                    
                    <Link to="/maquinariosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={trator1} alt="trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Trator Massey Ferguson</h1></div>
                        <div className={styles.desc}><h1>Trator Massey Ferguson MF 275 porte médio, 75 cv</h1></div>
                        <div className={styles.preco}><h1>R$ 150.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lençóis Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/maquinariosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={trator2} alt="trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Colheitadeira John Deere</h1></div>
                        <div className={styles.desc}><h1>Colheitadeira John Deere S430 com Sistema de Limpeza DF4</h1></div>
                        <div className={styles.preco}><h1>R$ 570.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lençóis Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/maquinariosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={trator3} alt="trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Trator Valtra</h1></div>
                        <div className={styles.desc}><h1>Trator Valtra A62s 4x4 Plataformado 67CV 2025 2 eixos</h1></div>
                        <div className={styles.preco}><h1>R$ 170.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lençóis Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/maquinariosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={trator4} alt="trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Pulverizador John Deere</h1></div>
                        <div className={styles.desc}><h1>Pulverizador Autopropelido John Deere M4030 Ano 2022</h1></div>
                        <div className={styles.preco}><h1>R$ 1.300.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lençóis Paulista - SP</h1></div>
                        </div>
                    </Link>

                    <Link to="/maquinariosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={trator5} alt="trator"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Colheitadeira Massey Ferguson</h1></div>
                        <div className={styles.desc}><h1>Colheitadeira Massey Ferguson MF 6690 ano 2021 (1460 h)</h1></div>
                        <div className={styles.preco}><h1>R$ 950.000,00</h1></div>
                        <div className={styles.endereco}><h1>Lençóis Paulista - SP</h1></div>
                        </div>
                    </Link>

                </div>

            </div>
        </div>
    );
}