import styles from "./servico.module.css";
import aplicacao from "../assets/aplicacao.png";
import colheita from "../assets/colheita.png";
import irrigacao from "../assets/irrigacao.png";
import arargem from "../assets/aragem.png";
import planejamento from "../assets/planejamento.png";

import { Link } from "react-router-dom";

export default function Produto(){
    return(
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.filtro}>
                    <div className={styles.fpreco}>
                        <h1>Preço</h1>

                        <div className={styles.marcar}>
                            <div className={styles.primeiro}>
                                <h2>R$100,00 até R$500,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.segundo}>
                                <h2>R$500,00 até R$1000,00</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.terceiro}>
                                <h2>R$1000,00 até R$5000,00</h2>
                                <input type="checkbox"/>
                            </div>

                            <div className={styles.menor}>
                                <h1>Menor Preço</h1>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.maior}>
                                <h1>Maior Preço</h1>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>

                    <div className={styles.fcategoria}>
                        <h1>Categorias</h1>

                        <div className={styles.marcar}>
                            <div className={styles.cprimeiro}>
                                <h2>Todos os Produtos</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.csegundo}>
                                <h2>Maquinários</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cterceiro}>
                                <h2>Peças</h2>
                                <input type="checkbox"/>
                            </div>
                            <div className={styles.cquarto}>
                                <h2>Serviços</h2>
                                <input type="checkbox"/>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={styles.gprod}>
                    
                    <Link to="/servicosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={aplicacao} alt="Aplicação de defensivos agrícolas"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Aplicação de defensivos agrícolas</h1></div>
                        <div className={styles.desc}><h1>Sou Ricardo, tenho 28 anos...</h1></div>
                        <div className={styles.preco}><h1>R$ 300,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>
                    
                    <Link to="/servicosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={colheita} alt="Colheita mecanizada"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Colheita mecanizada</h1></div>
                        <div className={styles.desc}><h1>Sou Ricardo, tenho 28 anos...</h1></div>
                        <div className={styles.preco}><h1>R$ 300,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>
                    
                    <Link to="/servicosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={irrigacao} alt="irrigacao"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Irrigação (instalação e manutenção)</h1></div>
                        <div className={styles.desc}><h1>Sou Ricardo, tenho 28 anos...</h1></div>
                        <div className={styles.preco}><h1>R$ 300,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>
                    
                    <Link to="/servicosVer" className={styles.produtos}>
                        <div className={styles.img}><img src={arargem} alt="Aragem"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Aragem de terra com trator</h1></div>
                        <div className={styles.desc}><h1>Sou Ricardo, tenh 28 anos...</h1></div>
                        <div className={styles.preco}><h1>R$ 300,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>
                    
                    <Link to="/servicosVer" className={styles.produtos}>
                    <div className={styles.img}><img src={planejamento} alt="Planejamento de plantio"/></div>
                        <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>Planejamento de plantio</h1></div>
                        <div className={styles.desc}><h1>Sou Ricardo, tenho 28 anos...</h1></div>
                        <div className={styles.preco}><h1>R$ 300,00</h1></div>
                        <div className={styles.endereco}><h1>Lencois Paulista - SP</h1></div>
                        </div>
                    </Link>

                    

                </div>

            </div>
        </div>
    );
}