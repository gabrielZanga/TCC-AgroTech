package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity

@Table(name = "anuncio")
public class Anuncio {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //@JsonIgnore
    @OneToOne
    @JoinColumn(name = "produto_id")
    private Produto produto;

    private String preco;

    private String descricao;

    private String status;
}
