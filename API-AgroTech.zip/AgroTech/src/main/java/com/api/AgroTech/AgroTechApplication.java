package com.api.AgroTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgroTechApplication.class, args);
	}

}
