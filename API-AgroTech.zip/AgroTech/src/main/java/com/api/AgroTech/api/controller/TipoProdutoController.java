package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.model.TipoProduto;
import com.api.AgroTech.domain.repository.TipoProdutoRepository;
import com.api.AgroTech.domain.service.TipoProdutoService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tiposProduto")
public class TipoProdutoController {
    @Autowired
    private TipoProdutoRepository tipoProdutoRepository;
    @Autowired
    private TipoProdutoService tipoProdutoService;

    @GetMapping
    public List<TipoProduto> listar() { return tipoProdutoRepository.findAll(); }

    @GetMapping("/{tiposProdutoId}")
    public ResponseEntity<TipoProduto> buscar(@PathVariable Long tipoProdutoId) {
        Optional<TipoProduto> tipoProduto = tipoProdutoRepository.findById(tipoProdutoId);

        if (tipoProduto.isPresent()) {
            return ResponseEntity.ok(tipoProduto.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<TipoProduto> adicionar(@RequestBody TipoProduto tipoProduto) {
        tipoProduto = tipoProdutoService.salvar(tipoProduto);
        return ResponseEntity.status(HttpStatus.CREATED).body(tipoProduto);
    }

    @PutMapping("/{tiposProdutoId}")
    public ResponseEntity<TipoProduto> atualizar (@PathVariable Long tipoProdutoId, @RequestBody TipoProduto tipoProduto) {
        Optional<TipoProduto> tipoProdutoAtual = tipoProdutoRepository.findById(tipoProdutoId);

        if (tipoProdutoAtual.isPresent()) {
            BeanUtils.copyProperties(tipoProduto, tipoProdutoAtual, "id");

            TipoProduto tipoProdutoSalvo = tipoProdutoService.salvar(tipoProdutoAtual.get());
            return ResponseEntity.ok(tipoProdutoSalvo);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{tiposProdutoId}")
    public ResponseEntity<TipoProduto> remover(@PathVariable Long tipoProdutoId) {
        try {
            tipoProdutoService.excluir(tipoProdutoId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
