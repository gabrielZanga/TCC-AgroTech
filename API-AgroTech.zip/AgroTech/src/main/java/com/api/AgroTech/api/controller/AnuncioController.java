package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Anuncio;
import com.api.AgroTech.domain.repository.AnuncioRepository;
import com.api.AgroTech.domain.service.AnuncioService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/anuncios")
public class AnuncioController {
    @Autowired
    private AnuncioRepository anuncioRepository;
    @Autowired
    private AnuncioService anuncioService;

    @GetMapping
    public List<Anuncio> listar() { return anuncioRepository.findAll(); }

    @GetMapping("/{anuncioId}")
    public ResponseEntity<Anuncio> buscar(@PathVariable Long anuncioId) {
        Optional<Anuncio> anuncio = anuncioRepository.findById(anuncioId);

        if (anuncio.isPresent()) {
            return ResponseEntity.ok(anuncio.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Anuncio> adicionar(@RequestBody Anuncio anuncio) {
        anuncio =anuncioService.salvar(anuncio);
        return ResponseEntity.status(HttpStatus.CREATED).body(anuncio);
    }

    @PutMapping("/{anuncioId}")
    public ResponseEntity<Anuncio> atualizar (@PathVariable Long anuncioId, @RequestBody Anuncio anuncio) {
        Optional<Anuncio> anuncioAtual =anuncioRepository.findById(anuncioId);

        if (anuncioAtual.isPresent()) {
            BeanUtils.copyProperties(anuncio, anuncioAtual, "id");

            Anuncio anuncioSalvo = anuncioService.salvar(anuncioAtual.get());
            return ResponseEntity.ok(anuncioSalvo);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{anuncioId}")
    public ResponseEntity<Anuncio> remover(@PathVariable Long anuncioId) {
        try {
            anuncioService.excluir(anuncioId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
