import Topo from '../../components/Topo'
import Menu from '../../components/Menu'
import Pecas from '../../components/Pecas'

export default function Produtos() {

    return (
      <div className="App">
        <div><Topo/></div>
        <div><Menu/></div>
        <div><Pecas/></div>
      </div>
    );
  }