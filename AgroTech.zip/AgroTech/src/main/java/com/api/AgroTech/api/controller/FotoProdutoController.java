package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.repository.FotoProdutoRepository;
import com.api.AgroTech.domain.service.FotoProdutoService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/fotoProdutos")
public class FotoProdutoController {
    @Autowired
    private FotoProdutoRepository fotoProdutoRepository;
    @Autowired
    private FotoProdutoService fotoProdutoService;

    @GetMapping
    public List<FotoProduto> listar() { return fotoProdutoRepository.findAll(); }

    @GetMapping("/{fotoProdutoId}")
    public ResponseEntity<FotoProduto> buscar(@PathVariable Long fotoProdutoId) {
        Optional<FotoProduto> fotoProduto = fotoProdutoRepository.findById(fotoProdutoId);

        if (fotoProduto.isPresent()) {
            return ResponseEntity.ok(fotoProduto.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<FotoProduto> adicionar(@RequestBody FotoProduto fotoProduto) {
        fotoProduto = fotoProdutoService.salvar(fotoProduto);
        return ResponseEntity.status(HttpStatus.CREATED).body(fotoProduto);
    }

    @PutMapping("/{fotoProdutoId}")
    public ResponseEntity<FotoProduto> atualizar (@PathVariable Long fotoProdutoId, @RequestBody FotoProduto fotoProduto) {
        Optional<FotoProduto> fotoProdutoAtual = fotoProdutoRepository.findById(fotoProdutoId);

        if (fotoProdutoAtual.isPresent()) {
            BeanUtils.copyProperties(fotoProduto, fotoProdutoAtual, "id");

            FotoProduto fotoProdutoSalva = fotoProdutoService.salvar(fotoProdutoAtual.get());
            return ResponseEntity.ok(fotoProdutoSalva);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{fotoprodutoId}")
    public ResponseEntity<FotoProduto> remover(@PathVariable Long fotoProdutoId) {
        try {
            fotoProdutoService.excluir(fotoProdutoId);
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
        catch (EntidadeEmUsoException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}
