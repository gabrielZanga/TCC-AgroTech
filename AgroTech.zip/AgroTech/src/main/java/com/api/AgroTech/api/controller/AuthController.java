package com.api.AgroTech.api.controller;


import com.api.AgroTech.domain.model.Cliente;
import com.api.AgroTech.domain.repository.ClienteRepository;
import com.api.AgroTech.dto.LoginRequestDTO;
import com.api.AgroTech.dto.RegisterRequestDTO;
import com.api.AgroTech.dto.ResponseDTO;
import com.api.AgroTech.infra.security.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired
    private ClienteRepository clienteRepository;


    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private TokenService tokenService;


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO body) {
        Optional<Cliente> user = clienteRepository.findByEmail(body.email());

        if (user.isEmpty())
            return ResponseEntity.status(401).body("Usuário não encontrado");

        Cliente cliente = user.get();

        if (!passwordEncoder.matches(body.password(), cliente.getSenha()))
            return ResponseEntity.status(401).body("Credenciais inválidas");

        String token = tokenService.generateToken(cliente);

        return ResponseEntity.ok(new ResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getEmail(),
                token
        ));
    }


    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDTO body) {

        if (clienteRepository.findByEmail(body.email()).isPresent()) {
            return ResponseEntity.status(409).body("Email já cadastrado");
        }

        Cliente cliente = new Cliente();
        cliente.setNome(body.name());
        cliente.setEmail(body.email());
        cliente.setSenha(passwordEncoder.encode(body.password()));

        // addressDTO → entidade


        // se tiver tipoUsuario obrigatório, me avise e adiciono aqui

        clienteRepository.save(cliente);

        String token = tokenService.generateToken(cliente);

        return ResponseEntity.ok(new ResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getEmail(),
                token

        ));
    }
}
