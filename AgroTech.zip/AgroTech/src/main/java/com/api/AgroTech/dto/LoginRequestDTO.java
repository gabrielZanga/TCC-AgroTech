package com.api.AgroTech.dto;

public record LoginRequestDTO(
        String email,
        String password
) {}
