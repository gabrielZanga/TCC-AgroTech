package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.Cidade;
import com.api.AgroTech.domain.model.Estado;
import com.api.AgroTech.domain.repository.CidadeRepository;
import com.api.AgroTech.domain.repository.EstadoRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/ibge")
@CrossOrigin(origins = "*")
public class IBGEController {

    @Autowired
    private EstadoRepository estadoRepository;

    @Autowired
    private CidadeRepository cidadeRepository;

    @GetMapping("/importar")
    @Transactional
    public ResponseEntity<String> importarEstadosECidades() {
        try {
            RestTemplate restTemplate = new RestTemplate();
            ObjectMapper mapper = new ObjectMapper();

            // ========== IMPORTA ESTADOS ==========
            String estadosJson = restTemplate.getForObject(
                    "https://servicodados.ibge.gov.br/api/v1/localidades/estados",
                    String.class
            );

            JsonNode estadosNode = mapper.readTree(estadosJson);

            for (JsonNode estadoNode : estadosNode) {

                Long estadoId = estadoNode.get("id").asLong();
                String nomeEstado = estadoNode.get("nome").asText();
                String sigla = estadoNode.get("sigla").asText();

                // Sempre cria um novo objeto, sem merge
                Estado estado = new Estado();
                estado.setId(estadoId);
                estado.setNome(nomeEstado);
                estado.setSigla(sigla);

                estadoRepository.save(estado);

                // ========== IMPORTA CIDADES DO ESTADO ==========
                String cidadesJson = restTemplate.getForObject(
                        "https://servicodados.ibge.gov.br/api/v1/localidades/estados/" + estadoId + "/municipios",
                        String.class
                );

                JsonNode cidadesNode = mapper.readTree(cidadesJson);

                for (JsonNode cidadeNode : cidadesNode) {

                    Long cidadeId = cidadeNode.get("id").asLong();
                    String nomeCidade = cidadeNode.get("nome").asText();

                    Cidade cidade = new Cidade();
                    cidade.setId(cidadeId);
                    cidade.setNome(nomeCidade);
                    cidade.setEstado(estado);

                    cidadeRepository.save(cidade);
                }
            }

            return ResponseEntity.ok("Importação concluída com sucesso!");

        } catch (Exception e) {
            return ResponseEntity.status(500).body("Erro: " + e.getMessage());
        }
    }
}
