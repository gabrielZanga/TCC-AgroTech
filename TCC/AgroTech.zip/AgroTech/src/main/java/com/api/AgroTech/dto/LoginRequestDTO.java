package com.api.AgroTech.dto;

import lombok.Data;

@Data
public class LoginRequestDTO {

    private Long id;

    private String nome;

    private String password;

    private String cpfCnpj;

    private String logradouro;

    private String numero;

    private String bairro;

    private String complemento;

    private Long cidadeId;

    private String email;
}

